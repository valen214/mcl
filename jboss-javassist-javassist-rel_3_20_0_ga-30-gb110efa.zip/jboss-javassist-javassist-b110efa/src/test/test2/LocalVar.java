package test2;

public class LocalVar {
    public String toString() { return "123"; }
    public int foo() { return toString().length(); }
}
